import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class spaceLite extends PApplet {

boolean firstFrameClick=true;
Boolean[] keys= new Boolean[14];
Table table;

boolean inGame = false;
boolean shop;
int gameMode = 0;
float score;
float scoreMulti=0;
float highscore;
float money=0;
boolean moneyGot;
float gamesPlayed;

Ship ship;
ArrayList<Astroid> astroids = new ArrayList<Astroid>();
ArrayList<Enemy> enemies = new ArrayList<Enemy>();
ArrayList<Bullet> bullets = new ArrayList<Bullet>();
ArrayList<MapExtras> mapExtras = new ArrayList<MapExtras>();
ArrayList<MineB> mines = new ArrayList<MineB>();
ArrayList<TowerField> towers = new ArrayList<TowerField>();
ArrayList<Item> items = new ArrayList<Item>();
float difficulty;

public void setup(){
  
  
  rectMode(CENTER);
  textAlign(CENTER, CENTER);
  frameRate(120);
  imageMode(CENTER);
  loadImg();
  table= loadTable("new.csv","header,csv");
  loadGameState();
  
  for(int i=0;i<keys.length;i++){
    keys[i]=false;
  }
}

public void draw(){
  background(0);
  
  
  if(!inGame){
    if(random(120/2)<1){ Astroid a = new Astroid(); }
    for(int i=0;i<astroids.size();i++){
      astroids.get(i).draw();
    }
    for(int i=0;i<astroids.size();i++){
      astroids.get(i).checkDistances(i);
    }
    for(int i=0;i<bullets.size();i++){
      bullets.get(i).draw();
    }
    for(int i=0;i<bullets.size();i++){
      bullets.get(i).checkDistances(i);
    }
    if(!shop){
      if(score>highscore)highscore=score;
      if(!moneyGot){
        moneyGot=true;
        money += (int)(score/10);
        saveData();
      }
      image(coverI,600,200,600,600);
      textC("money: "+(int)money,100, 25, 20, 255);
      textC("+ "+(int)(score/10),100, 50, 20, 255);
      textC("score: "+(int)score,100, 75, 20, 255);
      textC("highscore: "+(int)highscore,100, 100, 20, 255);
      fill(20);
      rect(600, 450, 400, 100);
      textC("normal game",600, 450, 30, 255);
      if(buttonPressed(600, 450, 400, 100))startGame(0);
      fill(20);
      rect(600, 600, 400, 100);
      textC("astroid mayham",600, 600, 30, 255);
      if(buttonPressed(600, 600, 400, 100))startGame(1);
      fill(20);
      rect(600, 750, 400, 100);
      textC("shop",600, 750, 30, 255);
      if(buttonPressed(600, 750, 400, 100))shop=true;
    }else{
      shop();
      
    }
  }else{
  //
  //  Ingame
  //
    score += scoreMulti/120;
    textC("score: "+(int)score,80, 25, 24, 255);
    textC("      x "+scoreMulti,80, 46, 18, 255);
    
    for(int i=0;i<mines.size();i++){
      mines.get(i).draw();
    }
    for(int i=0;i<mines.size();i++){
      mines.get(i).checkDistances(i);
    }
    for(int i=0;i<towers.size();i++){
      towers.get(i).draw();
    }
    ship.draw();
    for(int i=0;i<astroids.size();i++){
      astroids.get(i).draw();
    }
    for(int i=0;i<astroids.size();i++){
      astroids.get(i).checkDistances(i);
    }
    for(int i=0;i<bullets.size();i++){
      bullets.get(i).draw();
    }
    for(int i=0;i<bullets.size();i++){
      bullets.get(i).checkDistances(i);
    }
    for(int i=0;i<enemies.size();i++){
      enemies.get(i).draw();
    }
    for(int i=0;i<enemies.size();i++){
      enemies.get(i).checkDistances();
    }
    for(int i=0;i<mapExtras.size();i++){
      mapExtras.get(i).draw();
    }
    for(int i=0;i<mapExtras.size();i++){
      mapExtras.get(i).checkDistances();
    }
    for(int i=0;i<items.size();i++){
      items.get(i).draw();
    }
    for(int i=0;i<items.size();i++){
      items.get(i).checkDistances();
    }
    
    //spawns
    if(gameMode==0){
      if(random(120/2)<1){ Astroid a = new Astroid(); }
      if(random(120/difficulty * 30)<1){ redShip r = new redShip(); }
      if(random(120/difficulty * 60)<1){ blueShip r = new blueShip(); }
      if(random(120*20)<1){ BombenFass r = new BombenFass(); }
      if(random((10+5+difficulty)*120) < 1+0.02f*bonusItems){ newItem();}
      if(random(120 * 3)<1) difficulty+=0.1f;
    }
    if(gameMode==1){
      if(random(120/difficulty)<1){ Astroid a = new Astroid(); }
      if(random(120 * 3)<1) difficulty+=0.1f;
    }
  }
  
  if (!keyPressed && !mousePressed)firstFrameClick=true;  
  if (keyPressed || mousePressed)firstFrameClick=false;
}

public void startGame(int mode){
  inGame=true;
  ship=new Ship();
  astroids.clear();
  enemies.clear();
  bullets.clear();
  mapExtras.clear();
  mines.clear();
  towers.clear();
  items.clear();
  difficulty=2;
  gameMode=mode;
  score=0;
  moneyGot=false;
  gamesPlayed++;
  scoreMulti=1+0.02f*bonusScore;
  for(int i=0;i<startItem;i++){
    newItem();
  }
}
class Astroid{

  float posX, posY;
  float speedX, speedY;
  float size;
  float angle;
  
  Astroid(){
    size=30+15*(int)Math.abs(1.3f*randomGaussian());
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    float speed = 1.5f;
    if(gameMode==1)speed = 2.1f;
    speedX=getSpeedX(r,speed);
    speedY=getSpeedY(r,speed);
    angle=random(TWO_PI);
    astroids.add(this);
  }
  
  public void draw(){
    posX=posX+speedX;
    posY=posY+speedY;
    turnImg(komet1I,posX,posY,size*2,size*2,angle);
  }
  
  public void checkDistances(int index){
    if(posX>1300 || posX<-100 || posY>1100 || posY<-100)astroids.remove(this);
    if(ship != null && distance(ship.posX,ship.posY,posX,posY)<(size+ship.size)/2)inGame=false;
    for(int i=1+index;i<astroids.size();i++){
      if( distance(astroids.get(i).posX,astroids.get(i).posY,posX,posY) < (astroids.get(i).size+size)/2)explode(astroids.get(i));
    }
  }
  
  public void explode(Astroid a){
    astroids.remove(this);
    astroids.remove(a);
    float pellets= 6;
    for(int i=0;i<pellets;i++){
      float speedX = 2.4f*cos(TWO_PI/pellets*i);
      float speedY = 2.4f*sin(TWO_PI/pellets*i);
      Bullet b = new Bullet((posX+a.posX)/2 + 7*speedX,(posY+a.posY)/2 + 7*speedY, speedX, speedY, 16);
      b.playerB=false;
    }
  }
  
  public void getHit(Bullet b){
    size-=15*b.dmg;
    if(size<30)astroids.remove(this);
    else{
      float weigth=size/15;
      speedX+=b.speedX/weigth;
      speedY+=b.speedY/weigth;
    }
  }
}
abstract class MapExtras{
  float posX, posY;
  float speedX, speedY;
  float size;
  float angle;
  
  public abstract void checkDistances();
  public abstract void draw();
  public abstract void getHit();
}

class BombenFass extends MapExtras{
  
  BombenFass(){
    size=50;  
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    speedX=getSpeedX(r,1.5f);
    speedY=getSpeedY(r,1.5f);
    angle=random(TWO_PI);
    mapExtras.add(this);
  }
  
  public void checkDistances(){
    if(distance(600,500,posX,posY)>2000)mapExtras.remove(this);
  }
  public void draw(){
    posX=posX+speedX;
    posY=posY+speedY;
    angle+=TWO_PI/120 /2;
    turnImg(bombfassI,posX,posY,size*2,size*2,angle);
  }
  public void getHit(){
    mapExtras.remove(this);
    float pellets = 16;
    for(int i=0;i<pellets;i++){
      float speedX = 3*cos(TWO_PI/pellets*i);
      float speedY = 3*sin(TWO_PI/pellets*i);
      Bullet b = new Bullet(posX + 14*speedX,posY + 14*speedY, speedX, speedY, 16);
      b.playerB=false;
    }
  }
}

class TowerField{
  float posX;
  float posY;
  float size;
  boolean nextShot;
  
  TowerField(float posX,float posY){
    size = 40;
    this.posX=posX;
    this.posY=posY;
    
    towers.add(this);
  }
  public void draw(){
    image(towerBaseI,posX,posY,size*2,size*2);
    turnImg(towerBarrelI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,mouseX,mouseY));
    
    if(ship.nextAttack+0.5f >= 120/ship.attackspeed){
      if(true){
      nextShot=false;
      float distance = distance(posX,posY,mouseX,mouseY);
      float speedX =ship.bulletSpeed*(mouseX-posX)/distance;
      float speedY =ship.bulletSpeed*(mouseY-posY)/distance;
      Bullet b = new Bullet(posX,posY, speedX, speedY, 12);
      b.weak=true;
      }else nextShot=true;
    }
  }
}
class Bullet{
  float posX, posY;
  float speedX, speedY;
  float dmg;
  float size;
  boolean playerB;
  boolean enemyB;
  int explosive;
  boolean weak;
  boolean crit;
  
  Bullet(float posX,float posY, float speedX,float speedY,float size){
    this.posX = posX;
    this.posY = posY;
    this.speedX = speedX;
    this.speedY = speedY;
    this.size = size;
    playerB=true;
    enemyB = false;
    dmg=1;
    bullets.add(this);
  }
  
  public void draw(){
    posX=posX+speedX;
    posY=posY+speedY;
    if(!playerB)fill(0xffFF6A24);
    else{
      fill(0xff4EB4B7);
      if(weak)fill(0xff4EB4B7);
    }
    int c = 0xff4EB4B7;
    ellipse(posX,posY,size,size);
    if(dmg>1.5f){
      fill(0);
      ellipse(posX,posY,size/2,size/2);
    }
  }
  
  public void checkDistances(int index){
    
    if(ship != null && !playerB && distance(ship.posX,ship.posY,posX,posY)<(size+ship.size)/2.0f)inGame=false;
    for(int i=0;i<astroids.size();i++){
      if(distance(astroids.get(i).posX,astroids.get(i).posY,posX,posY)<(astroids.get(i).size+size)/2.0f){
        float aHp=astroids.get(i).size/15-1;
        astroids.get(i).getHit(this);
        dmg -= aHp;
        break;
      }
    }
    for(int i=0;i<mapExtras.size();i++){
      if(distance(mapExtras.get(i).posX,mapExtras.get(i).posY,posX,posY)<(mapExtras.get(i).size+size)/2.0f){
        mapExtras.get(i).getHit();
        dmg=0;
        break;
      }
    }
    if(!enemyB){
      for(int i=0;i<enemies.size();i++){
        if(distance(enemies.get(i).posX,enemies.get(i).posY,posX,posY)<(enemies.get(i).size+size)/2.0f){
          float eHp=enemies.get(i).hp;
          enemies.get(i).getHit(dmg);
          dmg -= eHp;
          break;
        }
      }
    }
    for(int i=index+1;i<bullets.size();i++){
      if(distance(bullets.get(i).posX,bullets.get(i).posY,posX,posY)<(bullets.get(i).size+size)/2.0f && !(playerB && bullets.get(i).playerB)){
        float bHp=bullets.get(i).dmg;
        bullets.get(i).dmg -= dmg;
        dmg -= bHp;
        break;
      }
    }
    if(posX>1200 || posX<0 || posY>1000 || posY<0){
      if(explosive<=0) bullets.remove(this);
      else{
        explosive--;
        if(posX>1200 || posX<0)speedX*=-1;
        else speedY*=-1;
      }
    }
    if(dmg<1)bullets.remove(this);
  }
}

class MoonB extends Bullet{
  float angle;
  float distance;
  float speed;
  
  MoonB(){
    super(ship.posX,ship.posY-40, 0,0,16);
    angle=0;
    distance=40;
    speed=random(4,12);
    if(random(100)<50)speed*=-1;
  }
  
  public void draw(){
    angle += TWO_PI/120/speed;
    angle = angle%TWO_PI;
    distance += ship.moons*1.5f/120/4;
    posX=ship.posX+distance*cos(angle);
    posY=ship.posY+distance*sin(angle);
    if(!playerB)fill(0xffFF6A24);
    else{
      fill(0xff4EB4B7);
      if(weak)fill(0xff4EB4B7);
    }
    ellipse(posX,posY,size,size);
    speedX = -4*(ship.posX-posX)/distance;
    speedY = -4*(ship.posY-posY)/distance;
  }
}

class SunB extends Bullet{
  float angle;
  float distance;
  float speed;
  float nextSprinkle;
  
  SunB(){
    super(ship.posX,ship.posY-260, 0,0,40);
    angle=0;
    distance=260;
    speed=random(3,6);
    if(random(100)<50)speed*=-1;
    nextSprinkle = ship.nextSprinkle;
  }
  
  public void draw(){
    angle += TWO_PI/120/speed;
    angle = angle%TWO_PI;
    posX=ship.posX+distance*cos(angle);
    posY=ship.posY+distance*sin(angle);
    if(!playerB)fill(0xffFF6A24);
    else{
      fill(0xff4EB4B7);
      if(weak)fill(0xff4EB4B7);
    }
    ellipse(posX,posY,size,size);
    
    speedX = -6*(ship.posX-posX)/distance;
    speedY = -6*(ship.posY-posY)/distance;
    
    if(false){
      nextSprinkle=120/ship.sprinkleSpeed;
      for(int i=0;i<ship.sprinkleShots;i++){
        float speedX = 3*cos(TWO_PI/ship.sprinkleShots*(i+0.5f));
        float speedY = 3*sin(TWO_PI/ship.sprinkleShots*(i+0.5f));
        Bullet b = new Bullet(posX,posY, speedX, speedY, 14);
        b.weak=true;
      }
    }else nextSprinkle--;
  }
  
  public void checkDistances(int index){
    
    if(!playerB && distance(ship.posX,ship.posY,posX,posY)<(size+ship.size)/2.0f)inGame=false;
    for(int i=0;i<astroids.size();i++){
      if(distance(astroids.get(i).posX,astroids.get(i).posY,posX,posY)<(astroids.get(i).size+size)/2.0f){
        float aHp=astroids.get(i).size/15-1;
        astroids.get(i).getHit(this);
        dmg -= aHp;
        break;
      }
    }
    for(int i=0;i<mapExtras.size();i++){
      if(distance(mapExtras.get(i).posX,mapExtras.get(i).posY,posX,posY)<(mapExtras.get(i).size+size)/2.0f){
        mapExtras.get(i).getHit();
        dmg=0;
        break;
      }
    }
    if(!enemyB){
      for(int i=0;i<enemies.size();i++){
        if(distance(enemies.get(i).posX,enemies.get(i).posY,posX,posY)<(enemies.get(i).size+size)/2.0f){
          float eHp=enemies.get(i).hp;
          enemies.get(i).getHit(dmg);
          dmg -= eHp;
          break;
        }
      }
    }
    for(int i=index+1;i<bullets.size();i++){
      if(distance(bullets.get(i).posX,bullets.get(i).posY,posX,posY)<(bullets.get(i).size+size)/2.0f && !(playerB && bullets.get(i).playerB)){
        float bHp=bullets.get(i).dmg;
        bullets.get(i).dmg -= dmg;
        dmg -= bHp;
        break;
      }
    }
    if(dmg<1)dmg=1;
  }
}

class MineB extends Bullet{
  
  MineB(float posX, float posY){
    super(posX,posY, 0,0,40);
    bullets.remove(this);
    mines.add(this);
  }

  public void draw(){
    image(mineFieldI,posX,posY,size*2,size*2);
  }
  
  public void checkDistances(int index){
    
    if(!enemyB){
      for(int i=0;i<enemies.size();i++){
        if(distance(enemies.get(i).posX,enemies.get(i).posY,posX,posY)<(enemies.get(i).size+size)/2.0f){
          float eHp=enemies.get(i).hp;
          enemies.get(i).getHit(dmg);
          dmg -= eHp;
          break;
        }
      }
    }
    
    if(dmg<1){
      mines.remove(this);
      float sprinkleShots=16;
      for(int i=0;i<sprinkleShots;i++){
          float speedX = 3*cos(TWO_PI/sprinkleShots*(i+0.5f));
          float speedY = 3*sin(TWO_PI/sprinkleShots*(i+0.5f));
          Bullet b = new Bullet(posX,posY, speedX, speedY, 16);
          b.weak=true;
          b.dmg=4;
        }
    }
  }
}
class Enemy{
  float posX, posY;
  float speedX, speedY;
  float speed;
  float size;
  float angle;
  float hp;
  int strength=1;
  boolean shield = false;
  
  Enemy(){
    hp=1;
    float r=random(4400);
    if(r<1200){
      posX=r;
      posY=-100;
    }else if(r<2400){
      posX=r-1200;
      posY=1100;
    }else if(r<3400){
      posX=-100;
      posY=r-2400;
    }else if(r<4400){
      posX=1300;
      posY=r-3400;
    }
    if(random(100)<3*(difficulty-4)){
      hp=hp+1;
      shield=true;
    }
    enemies.add(this);
  }
  
  public void getHit(float dmg){
    hp -= dmg;
    if(shield)shield=false;
    else{ if(size>100){
        size-=5;
      }else{
        size-=10;
      }
    }
    if(hp<1){
      enemies.remove(this);
      score+=5*scoreMulti;
    }
  }
  
  public void draw(){
  }
  
  public void checkDistances(){
    if(distance(ship.posX,ship.posY,posX,posY)<(size+ship.size)/2)inGame=false;
  }
}

class redShip extends Enemy{
  
  redShip(){
    super();
    speed = 1.6f;
    size=26;
    while(random(100)>1000/difficulty){
      if(size<100)size+=10;
      else size+=5;
      hp=hp+1;
      strength++;
    }
  }
  
  public void draw(){
    float distance = distance(posX,posY,ship.posX,ship.posY);
    speedX = speed*(ship.posX-posX)/distance;
    speedY = speed*(ship.posY-posY)/distance;
    posX = posX+speedX;
    posY = posY+speedY;
    
    turnImg(redShipI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,ship.posX, ship.posY));
    if(shield) turnImg(enemShieldI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,ship.posX, ship.posY));
  }
}

class blueShip extends Enemy{
  int nextShot;
  
  blueShip(){
    super();
    speed = 0.8f;
    size=26;
    while(random(100)>1000/difficulty){
      if(size<100)size+=10;
      else size+=5;
      hp=hp+1;
      strength++;
    }
    nextShot=60/strength + 60;
  }
  
  public void draw(){

    float distance = distance(posX,posY,ship.posX,ship.posY);
    speedX = speed*(ship.posX-posX)/distance;
    speedY = speed*(ship.posY-posY)/distance;
    posX = posX+speedX;
    posY = posY+speedY;
    turnImg(blueShipI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,ship.posX, ship.posY));
    if(shield) turnImg(enemShieldI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,ship.posX, ship.posY));
    
    if(nextShot<=0){
      
      float bSpeedX =4*(ship.posX-posX)/distance;
      float bSpeedY =4*(ship.posY-posY)/distance;
      Bullet b = new Bullet(posX,posY, bSpeedX, bSpeedY, 13);
      b.playerB = false;
      b.enemyB = true;
      b.size+= 3 * strength;
      nextShot=240 / strength;
    }else nextShot--;
  }
}
public void newItem(){
  float r = random(100);
  if(r < 70){
    int s = (int)random(6);
    switch(s){
    case 0:
      ASUp a = new ASUp();
      break;
    case 1:
      SprinkleShots ss = new SprinkleShots();
      break;
    case 2:
      Backshot bs = new Backshot();
      break;
    case 3:
      Crit crt = new Crit();
      break;
    case 4:
      if(score>100){Twenty tw = new Twenty();
      }else{newItem();}
      break;
    case 5:
      Mine mi = new Mine();
      break;
    }
    
  }else if(r < 91){
    int s = (int)random(5);
    switch(s){
    case 0:
      BSUp b = new BSUp();
      break;
    case 1:
      MoreSprinkleShots ms = new MoreSprinkleShots();
      break;
    case 2:
      Moon mo = new Moon();
      break;
    case 3:
      Tower t = new Tower();
      break;
    case 4:
      ScoreMulti sm = new ScoreMulti();
      break;
    }  
    
  }else{
    int s = (int)random(4);
    switch(s){
    case 0:
      ShotsUp su = new ShotsUp();
      break;
    case 1:
      Explosive e = new Explosive();
      break;
    case 2:
      Sun sn = new Sun();
      break;
    case 3:
      Dmg dmg = new Dmg();
      break;
    }
  }
}

class Item{
  float posX, posY;
  float speedX, speedY;
  float size;
  PImage img;
  
  public void draw(){
    posX+=speedX;
    posY+=speedY;
    image(img,posX,posY,1.6f*size,1.6f*size);
  }
  public void checkDistances(){
    if(distance(ship.posX,ship.posY,posX,posY)<(size+ship.size)/2)trigger();
  }
  public void trigger(){
  }
  public void calcSpeed(){
    float rX = random(-300,300);
    float rY = random(-250,250);
    float dist = distance(600+rX,500-rY, posX,posY);
    speedX=1.2f*(600+rX-posX)/dist;
    speedY=1.2f*(500-rY-posY)/dist;
  }
}

class ASUp extends Item{
  
  ASUp(){
    img=ASI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    ship.attackspeed *= 1.2f;
  }
}
class BSUp extends Item{
  
  BSUp(){
    img=BSI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    ship.bulletSize += 3;
  }
}

class ShotsUp extends Item{
  
  ShotsUp(){
    img=shotsUpI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    ship.shots += 1;
  }
}

class SprinkleShots extends Item{
  
  SprinkleShots(){
    img=sprinkleShotsI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    ship.sprinkleSpeed *= 1.2f;
  }
}

class MoreSprinkleShots extends Item{
  
  MoreSprinkleShots(){
    img=moreSprinkleShotsI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    ship.sprinkleSpeed *= 1.1f;
    ship.sprinkleShots += 4;
  }
}

class Backshot extends Item{
  
  Backshot(){
    img=backshotI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    ship.backshotProb += 0.25f;
    if(ship.backshotProb>1)ship.attackspeed *= 1.2f;
  }
}

class Explosive extends Item{
  
  Explosive(){
    img=explosiveI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    ship.explosive += 1;
  }
}

class Moon extends Item{
  
  Moon(){
    img=moonI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    ship.moons += 1;
  }
}

class Sun extends Item{
  
  Sun(){
    img=sunI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    SunB s = new SunB();
    //ship.sprinkleSpeed *= 1.1;
    //ship.sprinkleShots+=4;
  }
}

class Dmg extends Item{
  
  Dmg(){
    img=dmgI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    ship.dmg += 1;
  }
}

class Crit extends Item{
  
  Crit(){
    img=critI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    ship.critProb += 0.1f;
    if(ship.critProb>1)ship.attackspeed *= 1.2f;
  }
}

class Twenty extends Item{
  
  Twenty(){
    img=twentyI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    score+=50*scoreMulti;
  }
}

class Mine extends Item{
  
  Mine(){
    img=mineI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    MineB m= new MineB(posX,posY);
  }
}

class Tower extends Item{
  
  Tower(){
    img=towerI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    TowerField t= new TowerField(posX,posY);
  }
}
class ScoreMulti extends Item{
  
  ScoreMulti(){
    img=scoreMultiI;
    size=60;
    float r=random(4400);
    posX=getPosX(r,size);
    posY=getPosY(r,size);
    calcSpeed();
    items.add(this);
  }
  
  public void trigger(){
    items.remove(this);
    scoreMulti += 0.1f;
  }
}
PImage coverI;
PImage shipI;
PImage shipTriebI;
PImage komet1I;
PImage bombfassI;
PImage ASI;
PImage mineI;
PImage mineFieldI;
PImage twentyI;
PImage backshotI;
PImage sprinkleShotsI;
PImage critI;
PImage BSI;
PImage moreSprinkleShotsI;
PImage moonI;
PImage scoreMultiI;
PImage towerI;
PImage towerBaseI;
PImage towerBarrelI;
PImage shotsUpI;
PImage explosiveI;
PImage sunI;
PImage dmgI;

PImage redShipI;
PImage blueShipI;
PImage enemShieldI;

public void loadImg(){
  coverI=loadImage("cover.png");
  shipI=loadImage("ship.png");
  shipTriebI=loadImage("shipTrieb.png");
  komet1I=loadImage("komet1.png");
  bombfassI=loadImage("bombfass.png");
  ASI=loadImage("AS.png");
  mineI=loadImage("Mine.png");
  mineFieldI=loadImage("MineField.png");
  twentyI=loadImage("twenty.png");
  sprinkleShotsI=loadImage("SprinkleShots.png");
  critI=loadImage("Crit.png");
  backshotI=loadImage("Backshot.png");
  BSI=loadImage("BS.png");
  scoreMultiI=loadImage("ScoreMulti.png");
  moreSprinkleShotsI=loadImage("MoreSprinkleShots.png");
  moonI=loadImage("Moon.png");
  towerI=loadImage("Tower.png");
  towerBaseI=loadImage("TowerBase.png");
  towerBarrelI=loadImage("TowerBarrel.png");
  shotsUpI=loadImage("ShotsUp.png");
  explosiveI=loadImage("Explosive.png");
  sunI=loadImage("Sun.png");
  dmgI=loadImage("Dmg.png");
  
  redShipI=loadImage("redShip.png");
  blueShipI=loadImage("blueShip.png");
  enemShieldI=loadImage("EnemShield.png");
}

public void loadGameState(){
  
  money=table.getInt(0,"value");
  highscore=table.getInt(1,"value");
  gamesPlayed=table.getInt(2,"value");
  
  bonusAttackSpeed=table.getInt(3,"value");
  bonusItems=table.getInt(4,"value");
  bonusScore=table.getInt(5,"value");
  startItem=table.getInt(6,"value");
  mystery=table.getInt(7,"value");
}

public void saveData(){
  
  table.getRow(0).setFloat("value",money);
  table.getRow(1).setFloat("value",highscore);
  table.getRow(2).setFloat("value",gamesPlayed);
  
  table.getRow(3).setInt("value",bonusAttackSpeed);
  table.getRow(4).setInt("value",bonusItems);
  table.getRow(5).setInt("value",bonusScore);
  table.getRow(6).setInt("value",startItem);
  table.getRow(7).setInt("value",mystery);
  
  saveTable(table, "data/new.csv");
}
public boolean buttonPressed(float posX, float posY, float sizeX, float sizeY) {
  if (mousePressed && firstFrameClick && mouseX<posX+sizeX/2 && mouseX>posX-sizeX/2 && mouseY<posY+sizeY/2 && mouseY>posY-sizeY/2) {
    return true;
  }
  return false;
}

public boolean buttonHold(float posX, float posY, float sizeX, float sizeY) {
  if (mousePressed && mouseX<posX+sizeX/2 && mouseX>posX-sizeX/2 && mouseY<posY+sizeY/2 && mouseY>posY-sizeY/2) {
    return true;
  }
  return false;
}

public void turnImg(PImage img,float x,float y,float sizeX,float sizeY,float degr){
  pushMatrix();
  translate(x,y);
  rotate(degr);
  image(img,0,0,sizeX,sizeY);
  popMatrix();
}

public void textC(String text,float x,float y, float size, int c){
  textSize(size);
  fill(c);
  text(text,x,y);
}

public float w(){
  return width/1000.0f;
}
public float h(){
  return height/800.0f;
}

public float distance(float x1, float y1, float x2, float y2) {
  float distance=(float)Math.sqrt(Math.pow(x1-x2, 2)+Math.pow(y1-y2, 2));
  return distance;
}

public float angle(float x1, float y1, float x2, float y2){
  float angle=0;
  angle=atan( (y2-y1) / (x2-x1));
  if(x1>x2)angle=PI+angle;
  if(x2-x1<=1 && x2-x1>=-1){
    if(y1<y2)angle=HALF_PI;
    if(y1>y2)angle=TWO_PI-HALF_PI;
  }
  
  return angle;
}

public float getPosX(float r,float size){
  if(r<1200){
      return r;
    }else if(r<2400){
      return r-1200;
    }else if(r<3400){
      return -size;
    }else if(r<4400){
      return 1200+size;
    }
    return 0;
}
public float getPosY(float r,float size){
  if(r<1200){
      return -size;
    }else if(r<2400){
      return 1000+size;
    }else if(r<3400){
      return r-2400;
    }else if(r<4400){
      return r-3400;
    }
    return 0;
}
public float getSpeedX(float r,float speed){
  if(r<1200){
      return random(-speed,speed);
    }else if(r<2400){
      return random(-speed,speed);
    }else if(r<3400){
      return random(speed/4,speed);
    }else if(r<4400){
      return random(-speed/4,-speed);
    }
    return 10;
}
public float getSpeedY(float r,float speed){
  if(r<1200){
      return random(speed/4,speed);
    }else if(r<2400){
      return random(-speed/4,-speed);
    }else if(r<3400){
      return random(-speed,speed);
    }else if(r<4400){
      return random(-speed,speed);
    }
    return 10;
}


public void keyPressed() {
  if (key=='w'||key=='W')keys[0]=true;
  if (key=='a'||key=='A')keys[1]=true;
  if (key=='s'||key=='S')keys[2]=true;
  if (key=='d'||key=='D')keys[3]=true;
  if (key=='q'||key=='Q')keys[4]=true;
  if (key=='e'||key=='E')keys[5]=true;
  if (key==' ')          keys[6]=true;
  if (key=='p'||key=='P')keys[7]=true;
  if (key=='m'||key=='M')keys[8]=true;
  if (key=='r'||key=='R')keys[9]=true;
  if (key==ESC) {
    key=0;
    keys[10]=true;
  }
  if (key==TAB) {
    key=0;
    keys[11]=true;
  }
}

public void mousePressed() {
  if (mouseButton==LEFT)keys[12]=true;
  if (mouseButton==RIGHT)keys[13]=true;
}

public void keyReleased() {
  if (key=='w'||key=='W')keys[0]=false;
  if (key=='a'||key=='A')keys[1]=false;
  if (key=='s'||key=='S')keys[2]=false;
  if (key=='d'||key=='D')keys[3]=false;
  if (key=='q'||key=='Q')keys[4]=false;
  if (key=='e'||key=='E')keys[5]=false;
  if (key==' ')          keys[6]=false;
  if (key=='p'||key=='P')keys[7]=false;
  if (key=='m'||key=='M')keys[8]=false;
  if (key=='r'||key=='R')keys[9]=false;
  if (key==ESC) {
    key=0;
    keys[10]=false;
  }
  if (key==TAB) {
    key=0;
    keys[11]=false;
  }
}

public void mouseReleased() {
  if (mouseButton==LEFT)keys[12]=false;
  if (mouseButton==RIGHT)keys[13]=false;
}
class Ship{
  float posX, posY;
  float speedX, speedY;
  float baseSpeed, speed;
  float size;
  float attackspeed;
  float nextAttack;
  float bulletSize;
  float sprinkleSpeed=0.2f;
  float nextSprinkle=0;
  float sprinkleShots=4;
  float shots=1;
  float critProb=0;
  float backshotProb=0;
  float explosive=0;
  float dmg=1;
  float shield=0;
  float bulletSpeed=6;
  float moons=0;
  float nextMoon;
  
  Ship(){
    posX=600;
    posY=500;
    size=26;
    speedX=0; speedY=0;
    speed=8/120.0f;
    bulletSize=16;
    attackspeed=2 + 0.04f*bonusAttackSpeed;
    nextAttack=120/attackspeed;
  }
  
  public void draw(){
    if(keys[6]){
      float dist = distance(mouseX,mouseY, posX,posY);
      speedX = speedX + speed*(mouseX-posX)/dist;
      speedY = speedY + speed*(mouseY-posY)/dist;
      turnImg(shipTriebI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,mouseX,mouseY));
    }else{
      turnImg(shipI,posX,posY,size*2,size*2,HALF_PI+angle(posX, posY,mouseX,mouseY));
    }
    if(nextAttack<=0 && !keys[12]){//
      nextAttack=120/attackspeed;
      float dist = distance(mouseX,mouseY, posX,posY);
      float angle=angle(posX,posY,mouseX,mouseY);
      
      //backshot
      if(random(1)<backshotProb){
        Bullet b = new Bullet(posX,posY, -bulletSpeed*cos(angle), -bulletSpeed*sin(angle), bulletSize);
        b.explosive=(int)explosive;
        if(random(1)<critProb){
          b.dmg=2*dmg;
          b.size*=2;
          b.crit=true;
        }else{
          b.dmg=dmg;
        }
      }
      
      angle+=(shots-1)*TWO_PI/100;
      for(int i=0;i<shots;i++){
        Bullet b = new Bullet(posX,posY, bulletSpeed*cos(angle-i*TWO_PI/50), bulletSpeed*sin(angle-i*TWO_PI/50), bulletSize);
        b.explosive=(int)explosive;
        if(random(1)<critProb){
          b.dmg=2*dmg;
          b.size*=2;
          b.crit=true;
        }else{
          b.dmg=dmg;
        }
      }
    }else nextAttack--;
    
    if(sprinkleSpeed>0.2f){
      if(nextSprinkle<=0){
        nextSprinkle=120/sprinkleSpeed;
        for(int i=0;i<sprinkleShots;i++){
          float speedX = 3*cos(TWO_PI/sprinkleShots*(i+0.5f));
          float speedY = 3*sin(TWO_PI/sprinkleShots*(i+0.5f));
          Bullet b = new Bullet(posX,posY, speedX, speedY, 12);
          b.weak=true;
        }
      }else{
        nextSprinkle--;
      }
    }
    if(moons>0){
      if(nextMoon<=0){
        nextMoon=120*35/moons;
        MoonB m = new MoonB();
      }else{
        nextMoon--;
      }
    }
    
    speedX=speedX*0.99f;
    speedY=speedY*0.99f;
    posX=posX+speedX;
    posY=posY+speedY;
    if(posX<0)posX=1200;
    if(posY<0)posY=1000;
    if(posX>1200)posX=0;
    if(posY>1000)posY=0;
  }
}

int bonusAttackSpeed=0;
int bonusItems=0;
int bonusScore=0;
int startItem=0;
int mystery=0;

public void shop(){
  textC("money: "+(int)money,600, 25, 30, 255);
  int price=0;
  
  price=(20+10*bonusAttackSpeed);
  if(shopButton("attackspeed+2%  |  "+ price +"$ ("+bonusAttackSpeed+")",220,100,price)){
    bonusAttackSpeed ++;
    saveData();
  }
  
  price=(30+15*bonusItems);
  if(shopButton("itemdrops+2%  |  "+ price +"$ ("+bonusItems+")",220,150,price)){
    bonusItems ++;
    saveData();
  }
  
  price=(50+25*bonusScore);
  if(shopButton("score+2%  |  "+ price +"$ ("+bonusScore+")",220,200,price)){
    bonusScore ++;
    saveData();
  }
  
  price=(1000  );
  if(shopButton("startitem+1  |  "+ price +"$ ("+startItem+")",220,250,price) && startItem==0){
    startItem ++;
    saveData();
  }
  
  price=(9999);
  if(shopButton("?????????  |  "+ price +"$ ",220,300,price) && mystery==0){
    mystery ++;
    saveData();
  }
  
  fill(20);
  rect(1100, 900, 400, 100);
  textC("exit",1050, 900, 30, 255);
  if(buttonPressed(1100, 900, 400, 100))shop=false;
}

public boolean shopButton(String name, float posX,float posY,float price){
  
  fill(20);
  if(money >= price) rect(posX, posY, 400, 40);
  textC(name,posX, posY, 20, 255);
  if(buttonPressed(posX, posY, 400, 50) && money >= price){
    money-=price;
    return true;
  }
  return false;
}
  public void settings() {  size(1200,1000,P2D);  smooth(8); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "spaceLite" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
